<?php 
    header('location:../logout.php');
?>