<?php

    include "../includes/php_functions.php";
?>
<?php    
echo GenerateRandomString(128);
?>