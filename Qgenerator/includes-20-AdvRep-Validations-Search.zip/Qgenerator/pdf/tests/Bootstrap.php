<?php

//Grab the composer Autoloader!
$autoloader = include dirname(__DIR__).'/vendor/autoload.php';
