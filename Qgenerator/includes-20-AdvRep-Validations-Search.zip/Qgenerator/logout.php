<?php
    include ('../includes/php_functions.php');
    logout_user();
    header('location:index.php');
?>