<h2>Excel File Uploader</h2>

<form enctype="multipart/form-data" action="excel-upload.php" method="post" >
	
	<label class="form-label span3" for="file">File</label>
	<input type="file" name="file" id="file" required />
	
	
	<br><br>
	<input type="submit" value="Submit" />

</form>