<div class="navbar-lg">
    <div class="navbar-primary">
        <nav class="navbar navbar" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="container">
                <div class="row vertical-align">
                    <div class="col-sm-8"> <img src="images/Sanovi-Logo-Mobile.png" class="img-responsive imagepad displayed" /> </div>
                    <div class="col-sm-4">
                        <div class="row">
                            <div class="logout"></div>
                            <div class="col-sm-12 last">
                                
                              
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </div>
</div>