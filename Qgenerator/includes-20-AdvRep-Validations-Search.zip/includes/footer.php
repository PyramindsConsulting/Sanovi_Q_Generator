<footer class="footer">
      <div class="container">
        <p class="text-muted"><center style="color:white;">Copyright © 2016 Sanovi
</center></p>
      </div>
    </footer>