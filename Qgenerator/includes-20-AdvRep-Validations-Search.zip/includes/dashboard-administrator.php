<div class="form-group addPersonPanel">
                        <div class="form-group">
                            <div class="col-sm-12">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <label class="radio-inline">
                                            <input type="checkbox" class="licence" id="admin" name="addPersons1" checked>&nbsp;&nbsp;Administrator </label>
                                    </div>
                                    <div class="panel-body collapse" id="add">
                                        <div class="form-group">
                                            <div class="col-sm-6">
                                                <center><a href="admin/adduser.php">Add User</a></center>
                                            </div>
                                            <div class="col-sm-6">
                                                <center><a href="admin/modifyuser.php">Modify User</a></center>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="form-group">
                                            <div class="col-sm-6">
                                                <center><a href="admin/deleteuser.php">Delete User</a></center>
                                            </div>
                                            <div class="col-sm-6">
                                                <center><a href="admin/resetpassword.php">Reset Password</a></center>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="form-group">
                                            <div class="col-sm-6">
                                                <center>Modify Table Values</center>
                                            </div>
                                            <div class="col-sm-6">
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>